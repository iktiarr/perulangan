print("===== MENCARI BILANGAN PRIMA =====")
print("")

while True:
    user = int(input("Masukkan angka awal  : "))

    if user <= 1:
        print("Angka awal harus lebih dari 1")
        ulangi = input("Apakah ingin melanjutkan? (y/t): ")
        if ulangi.lower() != "y":
            break
        else:
            continue
    batas = int(input("Masukkan angka akhir : "))
    
    while user <= batas:
        if user == 2 or user == 3 or user == 5 or user == 7:
            print(user, end="  ")
        elif user % 2 != 0 and user % 3 != 0 and user % 5 != 0 and user % 7 != 0:
            print(user, end="  ")
        user += 1

    ulangi = input("\nApakah ingin mengulang pertanyaan lagi? (y/t): ")
    if ulangi.lower() != "y":
        break

print("Terima kasih telah menggunakan program ini")