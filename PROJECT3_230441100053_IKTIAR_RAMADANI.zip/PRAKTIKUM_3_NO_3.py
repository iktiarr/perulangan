print("===== MENGHITUNG DENDA =====")
print("")
def hitung_denda(lama_meminjam) :
    dendahari = 2000
    dendaminggu = 5000
    total = 0

    if lama_meminjam > 7:
        total += (lama_meminjam - 7) * dendahari

    if lama_meminjam > 7:
        total += (lama_meminjam - 7) // 7 * dendaminggu

    return total

while True:
    lama_meminjam = int(input("Masukkan lama peminjaman buku (dalam hari): "))
    
    if lama_meminjam <= 1:
        print("salah, Harus memasukkan minimal 1 atau lebih")
    elif 1 <= lama_meminjam <= 7:
        print("Anda tidak perlu membayar denda karena meminjam kurang dari 7 hari.")
    
    else:
        denda = hitung_denda(lama_meminjam)
        print("Denda yang harus dibayar adalah Rp", denda)

    ulangi = input("Apakah ingin menghitung lagi? (y/t): ")
    if ulangi.lower() != "y":
        break
